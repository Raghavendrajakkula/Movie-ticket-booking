package model;

import java.sql.Date;
import java.sql.Time;

public class Show {
    private int showId;
    private String movieTitle;
    private Date showDate;
    private Time showTime;
    private int roomNo;
    private double price;
    private int availableSeats;

    public Show(int showId, String movieTitle, Date showDate, Time showTime, int roomNo, double price, int availableSeats) {
        this.showId = showId;
        this.movieTitle = movieTitle;
        this.showDate = showDate;
        this.showTime = showTime;
        this.roomNo = roomNo;
        this.price = price;
        this.availableSeats = availableSeats;
    }

    // Getters
    public int getShowId() { return showId; }
    public String getMovieTitle() { return movieTitle; }
    public Date getShowDate() { return showDate; }
    public Time getShowTime() { return showTime; }
    public int getRoomNo() { return roomNo; }
    public double getPrice() { return price; }
    public int getAvailableSeats() { return availableSeats; }

    // Setters (optional)
    public void setAvailableSeats(int availableSeats) {
        this.availableSeats = availableSeats;
    }
}

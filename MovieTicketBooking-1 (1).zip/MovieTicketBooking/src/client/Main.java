package client;
// Final Assignment: Online Movie ticket Booking 
// Date: 2025-11-05
// Name: Gowrish Karthic
//		 Ritik Katkam


import model.DatabaseConnector;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;

public class Main {

    private static JFrame mainFrame;
    private static JPanel mainPanel;
    private static CardLayout cardLayout;

    public static void main(String[] args) {
        try {
            Connection conn = DatabaseConnector.getConnection();
            System.out.println("Connected to DB!");
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Initialize main frame and panels
        SwingUtilities.invokeLater(() -> {
            createAndShowGUI();
        });
    }

    private static void createAndShowGUI() {
        mainFrame = new JFrame("Movie Ticket Reservation");
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame.setSize(800, 600);

        mainPanel = new JPanel();
        cardLayout = new CardLayout();
        mainPanel.setLayout(cardLayout);

        // Create initial screen panels
        LoginScreen loginScreen = new LoginScreen(mainPanel, cardLayout);
        SignupScreen signupScreen = new SignupScreen(mainPanel, cardLayout);

        // Add initial panels to the main panel with names
        mainPanel.add(loginScreen, "login");
        mainPanel.add(signupScreen, "signup");

        mainFrame.add(mainPanel);
        mainFrame.setLocationRelativeTo(null);
        mainFrame.setVisible(true);

        // Show the initial screen
        cardLayout.show(mainPanel, "login"); // Show Login Screen first
    }

    public static void showScreen(String screenName) {
        cardLayout.show(mainPanel, screenName);
    }
}
package client;

import server.ReservationServer;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import java.awt.*;
import java.util.List;

public class ChefScreen extends JPanel { // Extend JPanel

    private ReservationServer server = new ReservationServer();
    private JTable table;
    private DefaultTableModel model;
    private JPanel mainPanel;
    private CardLayout cardLayout;

    public ChefScreen(JPanel mainPanel, CardLayout cardLayout) { // Modified Constructor
        this.mainPanel = mainPanel;
        this.cardLayout = cardLayout;
        setLayout(new BorderLayout());

        // Table Columns
        String[] columns = {"Reservation ID", "Username", "Movie", "Date", "Time", "Tickets", "Current Status", "New Status"};
        model = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                // Only allow editing for "New Status" column
                return column == 7;
            }
        };
        table = new JTable(model);

        // Prevent column reordering
        table.getTableHeader().setReorderingAllowed(false);

        // Dropdown for "New Status"
        String[] statuses = {"Placed", "Preparing", "Ready", "Completed"};
        JComboBox<String> statusDropdown = new JComboBox<>(statuses);
        TableColumn statusCol = table.getColumnModel().getColumn(7);
        statusCol.setCellEditor(new DefaultCellEditor(statusDropdown));

        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // Load reservation data
        loadReservationData();

        // Update Button
        JButton updateBtn = new JButton("Update Selected Status");
        updateBtn.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow >= 0) {

                // ✅ Commit dropdown selection
                if (table.isEditing()) {
                    table.getCellEditor().stopCellEditing();
                }

                int resId = Integer.parseInt(model.getValueAt(selectedRow, 0).toString());
                String newStatus = model.getValueAt(selectedRow, 7).toString();

                boolean success = server.updateReservationStatus(resId, newStatus);
                if (success) {
                    model.setValueAt(newStatus, selectedRow, 6); // ✅ Update "Current Status"
                    JOptionPane.showMessageDialog(this, "✅ Status updated successfully."); // Use 'this'
                    loadReservationData(); // Refresh the table
                } else {
                    JOptionPane.showMessageDialog(this, "❌ Failed to update status."); // Use 'this'
                }

            } else {
                JOptionPane.showMessageDialog(this, "Please select a row."); // Use 'this'
            }
        });

        JPanel bottomPanel = new JPanel(new FlowLayout());
        bottomPanel.add(updateBtn);
        JButton backToLoginBtn = new JButton("Back to Login"); // Back to Login Button
        bottomPanel.add(backToLoginBtn);
        add(bottomPanel, BorderLayout.SOUTH);

        backToLoginBtn.addActionListener(e -> {
            mainPanel.remove(this);
            cardLayout.show(mainPanel, "login");
        });

        // frame.setLocationRelativeTo(null); // No frame operations
        // frame.setVisible(true);
    }

    private void loadReservationData() {
        model.setRowCount(0); // Clear existing data
        List<String[]> reservations = server.getAllReservationsForChef();
        for (String[] row : reservations) {
            model.addRow(new Object[]{
                    row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[6] // Current and New Status
            });
        }
    }

    // public static void main(String[] args) {
    //     new ChefScreen();
    // }
}
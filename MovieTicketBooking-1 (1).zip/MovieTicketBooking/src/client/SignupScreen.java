package client;

import model.User;
import server.ReservationServer;

import javax.swing.*;
import java.awt.*;

public class SignupScreen extends JPanel {
    private ReservationServer server = new ReservationServer();
    private JPanel mainPanel;
    private CardLayout cardLayout;

    public SignupScreen(JPanel mainPanel, CardLayout cardLayout) {
        this.mainPanel = mainPanel;
        this.cardLayout = cardLayout;
        setLayout(new GridLayout(8, 2));

        // UI Components
        JTextField firstNameField = new JTextField();
        JTextField lastNameField = new JTextField();
        JTextField usernameField = new JTextField();
        JPasswordField passwordField = new JPasswordField();
        JTextField emailField = new JTextField();
        JTextField phoneField = new JTextField();
        JTextField addressField = new JTextField();
        JButton registerBtn = new JButton("Register");
        JButton backToLoginBtn = new JButton("Back to Login");

        // Add to Frame
        add(new JLabel("First Name:"));
        add(firstNameField);
        add(new JLabel("Last Name:"));
        add(lastNameField);
        add(new JLabel("Username:"));
        add(usernameField);
        add(new JLabel("Password:"));
        add(passwordField);
        add(new JLabel("Email:"));
        add(emailField);
        add(new JLabel("Phone:"));
        add(phoneField);
        add(new JLabel("Address:"));
        add(addressField);
        add(registerBtn);
        add(backToLoginBtn);

        // Register Action
        registerBtn.addActionListener(e -> {
            String first = firstNameField.getText().trim();
            String last = lastNameField.getText().trim();
            String username = usernameField.getText().trim();
            String password = new String(passwordField.getPassword()).trim();
            String email = emailField.getText().trim();
            String phone = phoneField.getText().trim();
            String address = addressField.getText().trim();

            // Validations
            if (!first.matches("[a-zA-Z]+")) {
                JOptionPane.showMessageDialog(this, "❌ First name must contain only letters.");
                return;
            }
            if (!last.matches("[a-zA-Z]+")) {
                JOptionPane.showMessageDialog(this, "❌ Last name must contain only letters.");
                return;
            }
            if (!email.endsWith("@gmail.com")) {
                JOptionPane.showMessageDialog(this, "❌ Email must be a valid @gmail.com address.");
                return;
            }
            if (!phone.matches("\\d{10}")) {
                JOptionPane.showMessageDialog(this, "❌ Phone number must be exactly 10 digits.");
                return;
            }
            if (username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(this, "❌ Username and password cannot be empty.");
                return;
            }

            // Register User
            User user = new User(username, password, first, last, email, phone, address, "Customer");
            boolean success = server.registerUser(user);

            if (success) {
                JOptionPane.showMessageDialog(this, "✅ Registration successful! You can now log in.");
                Main.showScreen("login");
            } else {
                JOptionPane.showMessageDialog(this, "❌ Registration failed. Try a different username.");
            }
        });

        backToLoginBtn.addActionListener(e -> {
            Main.showScreen("login");
        });

        //        frame.setLocationRelativeTo(null);
        //        frame.setVisible(true);
    }

    //    public static void main(String[] args) {
    //        new SignupScreen();
    //    }
}
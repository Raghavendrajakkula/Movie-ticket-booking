package client;

import server.ReservationServer;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import model.DatabaseConnector; // Import your DatabaseConnector

public class LoginScreen extends JPanel {

    private JPanel mainPanel;
    private CardLayout cardLayout;

    public LoginScreen(JPanel mainPanel, CardLayout cardLayout) {
        this.mainPanel = mainPanel;
        this.cardLayout = cardLayout;
        setLayout(new GridLayout(5, 2));

        // UI components
        JLabel roleLabel = new JLabel("Role:");
        String[] roles = {"Customer", "DBA", "Chef"};
        JComboBox<String> roleCombo = new JComboBox<>(roles);

        JLabel userLabel = new JLabel("Username:");
        JTextField userField = new JTextField();

        JLabel passLabel = new JLabel("Password:");
        JPasswordField passField = new JPasswordField();

        JButton loginBtn = new JButton("Login");
        JButton signupBtn = new JButton("Signup");
        JLabel resultLabel = new JLabel("");

        // Add to frame
        add(roleLabel);
        add(roleCombo);
        add(userLabel);
        add(userField);
        add(passLabel);
        add(passField);
        add(loginBtn);
        add(signupBtn);
        add(resultLabel);

        // Action handler
        loginBtn.addActionListener(e -> {
            String role = (String) roleCombo.getSelectedItem();
            String username = userField.getText().trim();
            String password = new String(passField.getPassword()).trim();

            if (username.isEmpty() || password.isEmpty()) {
                resultLabel.setText("⚠️ Missing credentials.");
                return;
            }

            ReservationServer server = new ReservationServer();
            boolean valid;

            if ("DBA".equals(role)) {
                // ✅ Hardcoded DBA login
                if ("admin".equals(username) && "admin".equals(password)) {
                    valid = true;
                } else {
                    valid = false;
                }
            } else if ("Chef".equals(role)) {
                // ✅ Hardcoded Chef login
                // ⚠️ INSECURE: Direct database check for mini-project ONLY!
                // ⚠️ DO NOT USE THIS IN PRODUCTION CODE!
                valid = checkChefCredentialsInDB(username, password);
            } else {
                // ✅ Authenticate customer from DB
                valid = server.authenticate(username, password, "Customer");
            }

            if (valid) {
                JOptionPane.showMessageDialog(this, "✅ Login successful as " + role + "!");

                if ("DBA".equals(role)) {
                    AdminScreen adminScreen = new AdminScreen(mainPanel, cardLayout);
                    mainPanel.add(adminScreen, "admin");
                    Main.showScreen("admin");
                } else if ("Chef".equals(role)) {
                    ChefScreen chefScreen = new ChefScreen(mainPanel, cardLayout);
                    mainPanel.add(chefScreen, "chef");
                    Main.showScreen("chef");
                } else {
                    CustomerScreen customerScreen = new CustomerScreen(username, mainPanel, cardLayout);
                    mainPanel.add(customerScreen, "customer");
                    Main.showScreen("customer");
                }
            } else {
                resultLabel.setText("❌ Login failed.");
            }
        });

        signupBtn.addActionListener(e -> {
            Main.showScreen("signup");
        });
    }

    private boolean checkChefCredentialsInDB(String username, String password) {
        // ⚠️ INSECURE: Database query - REPLACE WITH HASHING!
        String sql = "SELECT * FROM RegisteredUser WHERE username = ? AND password = ? AND role = 'Chef'";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, username);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();
            return rs.next(); // Returns true if a match is found
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
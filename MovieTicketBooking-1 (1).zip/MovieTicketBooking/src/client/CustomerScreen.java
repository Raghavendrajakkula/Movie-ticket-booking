package client;

import model.Show;
import server.ReservationServer;

import javax.swing.*;
import java.awt.*;
import java.sql.Date;
import java.util.List;
import java.util.ArrayList;

public class CustomerScreen extends JPanel {

    private String username;
    private ReservationServer server = new ReservationServer();
    private JPanel mainPanel;
    private CardLayout cardLayout;
    private JTextArea outputArea = new JTextArea(); // Declare as a field
    private List<String> allTicketDetails = new ArrayList<>();

    public CustomerScreen(String username, JPanel mainPanel, CardLayout cardLayout) {
        this.username = username;
        this.mainPanel = mainPanel;
        this.cardLayout = cardLayout;

        setLayout(new BorderLayout());

        JPanel topPanel = new JPanel(new FlowLayout());
        JLabel dateLabel = new JLabel("Enter Date (YYYY-MM-DD):");
        JTextField dateField = new JTextField(10);
        JButton loadBtn = new JButton("Check Shows");

        topPanel.add(dateLabel);
        topPanel.add(dateField);
        topPanel.add(loadBtn);

        outputArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(outputArea);

        JPanel bottomPanel = new JPanel(new FlowLayout());
        JButton reserveBtn = new JButton("Reserve Ticket");
        JButton viewBtn = new JButton("My Reservations");
        JButton cancelBtn = new JButton("Cancel Reservation");
        JButton backToLoginBtn = new JButton("Back to Login");
        JButton printAllTicketsBtn = new JButton("Print All Tickets"); // Changed button text

        bottomPanel.add(reserveBtn);
        bottomPanel.add(viewBtn);
        bottomPanel.add(cancelBtn);
        bottomPanel.add(backToLoginBtn);
        bottomPanel.add(printAllTicketsBtn); // Use the modified button

        add(topPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

        // Load shows
        loadBtn.addActionListener(e -> {
            try {
                Date date = Date.valueOf(dateField.getText().trim());
                List<Show> shows = server.getAvailableShows(date);
                outputArea.setText("");
                if (shows.isEmpty()) {
                    outputArea.setText("❌ No shows found for this date.");
                } else {
                    for (Show s : shows) {
                        outputArea.append("Show ID: " + s.getShowId() +
                                ", Movie: " + s.getMovieTitle() +
                                ", Time: " + s.getShowTime() +
                                ", Room: " + s.getRoomNo() +
                                ", Price: $" + s.getPrice() +
                                ", Available: " + s.getAvailableSeats() + "\n");
                    }
                }
            } catch (Exception ex) {
                outputArea.setText("❌ Invalid date format.");
            }
        });

        // Reserve ticket
        reserveBtn.addActionListener(e -> {
            try {
                int showId = Integer.parseInt(JOptionPane.showInputDialog("Enter Show ID:"));
                int count = Integer.parseInt(JOptionPane.showInputDialog("Number of tickets:"));
                String card = JOptionPane.showInputDialog("Credit Card (5 digits):").trim();

                double price = 10.0;
                double total = price * count;

                boolean reserved = server.makeReservation(username, showId, count, card, total);

                if (reserved) {
                    JOptionPane.showMessageDialog(this, "✅ Reservation successful!");
                    // Store ticket details
                    String ticketDetails = "🎫 Ticket Details 🎫\n" +
                            "Username: " + username + "\n" +
                            "Show ID: " + showId + "\n" +
                            "Tickets: " + count + "\n" +
                            "Total: $" + total + "\n--------------------\n";
                    allTicketDetails.add(ticketDetails);
                    // loadBtn.doClick(); // Refresh show list (if needed)
                } else {
                    JOptionPane.showMessageDialog(this, "❌ Reservation failed. Check seats/card or duplicate booking.");
                }

            } catch (IllegalArgumentException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage()); // Display specific error
            }

             catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "❌ Invalid input: " + ex.getMessage());
            }
        });

        // View reservations
        viewBtn.addActionListener(e -> {
            String res = server.getUserReservations(username);
            outputArea.setText(res);
            allTicketDetails.clear();
            if (!res.equals("❌ No reservations found.") && !res.equals("❌ Error retrieving reservations.")) {
                allTicketDetails.add(res);
            }
        });

        // Cancel reservation
        cancelBtn.addActionListener(e -> {
            try {
                int resId = Integer.parseInt(JOptionPane.showInputDialog("Enter Reservation ID to cancel:"));
                boolean result = server.cancelReservation(resId);
                if (result) {
                    JOptionPane.showMessageDialog(this, "✅ Reservation cancelled.");
                    viewBtn.doClick(); // Refresh reservation list
                } else {
                    JOptionPane.showMessageDialog(this, "❌ Cannot cancel — must be at least 1 hour before showtime.");
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "❌ Invalid input or reservation not found.");
            }
        });

        // Back to Login Button
        backToLoginBtn.addActionListener(e -> {
            mainPanel.remove(this);
            cardLayout.show(mainPanel, "login");
        });

        // Print All Tickets
        printAllTicketsBtn.addActionListener(e -> {
            String allReservations = server.getUserReservations(username); // Fetch all reservations

            if (!allReservations.equals("❌ No reservations found.") && !allReservations.equals("❌ Error retrieving reservations.")) {
                List<String> details = new ArrayList<>();
                details.add(allReservations);
                displayAllTickets(details);
            } else {
                JOptionPane.showMessageDialog(this, "❌ No reservations to print.");
            }
        });
    }

    

    private void displayAllTickets(List<String> details) {
        StringBuilder allDetails = new StringBuilder();
        for (String detail : details) {
            allDetails.append(detail).append(details.size() > 1 ? "\n--------------------\n" : "\n");
        }
        JTextArea ticketArea = new JTextArea(allDetails.toString());
        ticketArea.setEditable(false);
        JOptionPane.showMessageDialog(this, new JScrollPane(ticketArea), "All Your Reservations", JOptionPane.INFORMATION_MESSAGE);
    }
}
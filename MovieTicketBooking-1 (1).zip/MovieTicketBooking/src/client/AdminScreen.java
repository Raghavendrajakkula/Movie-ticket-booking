package client;

import server.ReservationServer;

import javax.swing.*;
import java.awt.*;

public class AdminScreen extends JPanel { // Extend JPanel
    private ReservationServer server = new ReservationServer();
    private JPanel mainPanel;
    private CardLayout cardLayout;
    private JTextArea resultArea = new JTextArea(); // Declare as a field

    public AdminScreen(JPanel mainPanel, CardLayout cardLayout) { // Modified Constructor
        this.mainPanel = mainPanel;
        this.cardLayout = cardLayout;
        setLayout(new BorderLayout());

        resultArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(resultArea);

        // Button panel with 5 buttons now (was 4)
        JPanel buttonPanel = new JPanel(new GridLayout(3, 2, 10, 10));

        JButton addMovieBtn = new JButton("Add Movie");
        JButton addShowBtn = new JButton("Add Show");
        JButton viewShowsBtn = new JButton("View All Shows");
        JButton deleteShowBtn = new JButton("Delete Show by ID");
        JButton updateShowBtn = new JButton("Update Show");
        JButton backToLoginBtn = new JButton("Back to Login"); // Back button

        buttonPanel.add(addMovieBtn);
        buttonPanel.add(addShowBtn);
        buttonPanel.add(viewShowsBtn);
        buttonPanel.add(deleteShowBtn);
        buttonPanel.add(updateShowBtn);
        buttonPanel.add(backToLoginBtn); // Add back button to panel

        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        // Add Movie
        addMovieBtn.addActionListener(e -> {
            JTextField titleField = new JTextField();
            JTextField rankField = new JTextField();
            JTextField reviewField = new JTextField();
            Object[] fields = {
                    "Title:", titleField,
                    "Rank (1-5):", rankField,
                    "Review:", reviewField
            };

            int option = JOptionPane.showConfirmDialog(this, fields, "Add New Movie", JOptionPane.OK_CANCEL_OPTION); // 'this'
            if (option == JOptionPane.OK_OPTION) {
                boolean success = server.addMovie(titleField.getText(), Integer.parseInt(rankField.getText()), reviewField.getText());
                if (success) {
                    resultArea.append("✅ Movie added.\n");
                    //  viewShowsBtn.doClick(); // If you had a movie list, you'd refresh it here
                } else {
                    resultArea.append("❌ Failed to add movie.\n");
                }
            }
        });

        // Add Show using title lookup
        addShowBtn.addActionListener(e -> {
            JTextField titleField = new JTextField();
            JTextField dateField = new JTextField();
            JTextField timeField = new JTextField();
            JTextField roomField = new JTextField();
            JTextField priceField = new JTextField();

            Object[] inputs = {
                "Movie Title:", titleField,
                "Date (YYYY-MM-DD):", dateField,
                "Time (HH:MM:SS):", timeField,
                "Room No:", roomField,
                "Price:", priceField
            };

            int option = JOptionPane.showConfirmDialog(this, inputs, "Add New Show", JOptionPane.OK_CANCEL_OPTION); // 'this'
            if (option == JOptionPane.OK_OPTION) {
                try {
                    String title = titleField.getText().trim();
                    int movieId = server.getMovieIdByTitle(title);
                    if (movieId == -1) {
                        JOptionPane.showMessageDialog(this, "❌ Movie title not found. Add it first via 'Add Movie'."); // 'this'
                        return;
                    }

                    boolean added = server.addShow(
                        movieId,
                        dateField.getText().trim(),
                        timeField.getText().trim(),
                        Integer.parseInt(roomField.getText().trim()),
                        Double.parseDouble(priceField.getText().trim())
                    );

                    if (!added) {
                        JOptionPane.showMessageDialog(this, "❌ Cannot add show. A different movie is already scheduled in the same room, date, and time."); // 'this'
                    } else {
                        resultArea.append("✅ Show added.\n");
                        viewShowsBtn.doClick(); // Refresh show list
                    }

                } catch (Exception ex) {
                    resultArea.append("❌ Invalid input: " + ex.getMessage() + "\n");
                }
            }
        });

        // View All Shows
        viewShowsBtn.addActionListener(e -> {
            String data = server.getAllShowsInfo();
            resultArea.setText(data);
        });

        // Delete Show
        deleteShowBtn.addActionListener(e -> {
            String showIdStr = JOptionPane.showInputDialog(this, "Enter Show ID to delete:"); // 'this'
            if (showIdStr != null) {
                try {
                    int showId = Integer.parseInt(showIdStr);
                    boolean deleted = server.deleteShow(showId);
                    resultArea.append(deleted ? "🗑️ Show deleted.\n" : "❌ Deletion failed.\n");
                    if (deleted) {
                        viewShowsBtn.doClick(); // Refresh show list
                    }
                } catch (NumberFormatException ex) {
                    resultArea.append("❌ Invalid show ID.\n");
                }
            }
        });

        // Update Show
        updateShowBtn.addActionListener(e -> {
            try {
                String showIdStr = JOptionPane.showInputDialog(this, "Enter Show ID to update:"); // 'this'
                if (showIdStr == null || showIdStr.isEmpty()) return;
                int showId = Integer.parseInt(showIdStr);

                JTextField titleField = new JTextField();
                JTextField rankField = new JTextField();
                JTextField reviewField = new JTextField();
                JTextField dateField = new JTextField();
                JTextField timeField = new JTextField();
                JTextField roomField = new JTextField();
                JTextField priceField = new JTextField();

                Object[] inputs = {
                    "New Movie Title:", titleField,
                    "New Rank (1-5):", rankField,
                    "New Review:", reviewField,
                    "New Date (YYYY-MM-DD):", dateField,
                    "New Time (HH:MM:SS):", timeField,
                    "New Room No:", roomField,
                    "New Ticket Price:", priceField
                };

                int option = JOptionPane.showConfirmDialog(this, inputs, "Update Show Details", JOptionPane.OK_CANCEL_OPTION); // 'this'
                if (option == JOptionPane.OK_OPTION) {
                    String newTitle = titleField.getText().trim();
                    int newRank = Integer.parseInt(rankField.getText().trim());
                    String newReview = reviewField.getText().trim();
                    String newDate = dateField.getText().trim();
                    String newTime = timeField.getText().trim();
                    int newRoom = Integer.parseInt(roomField.getText().trim());
                    double newPrice = Double.parseDouble(priceField.getText().trim());

                    boolean updated = server.updateShowDetails(showId, newTitle, newRank, newReview, newDate, newTime, newRoom, newPrice);
                    resultArea.append(updated ? "✅ Show updated.\n" : "❌ Failed to update show.\n");
                    if (updated) {
                        viewShowsBtn.doClick(); // Refresh show list
                    }
                }
            } catch (Exception ex) {
                resultArea.append("❌ Invalid input or error occurred: " + ex.getMessage() + "\n");
            }
        });

        // Back to Login
        backToLoginBtn.addActionListener(e -> {
            mainPanel.remove(this);
            cardLayout.show(mainPanel, "login");
        });

        //    frame.setLocationRelativeTo(null);
        //    frame.setVisible(true);
    }

    //    public static void main(String[] args) {
    //        new AdminScreen();
    //    }
}
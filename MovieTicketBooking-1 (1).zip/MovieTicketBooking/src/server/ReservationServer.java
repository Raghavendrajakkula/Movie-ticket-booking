package server;

import model.DatabaseConnector;
import model.Show;
import model.User;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ReservationServer {

    // Register new user
    public boolean registerUser(User user) {
        String sql = "INSERT INTO RegisteredUser (username, password, first_name, last_name, email, phone, address, role) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, user.getUsername());
            stmt.setString(2, user.getPassword());
            stmt.setString(3, user.getFirstName());
            stmt.setString(4, user.getLastName());
            stmt.setString(5, user.getEmail());
            stmt.setString(6, user.getPhone());
            stmt.setString(7, user.getAddress());
            stmt.setString(8, user.getRole());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean authenticate(String username, String password, String role) {
        String sql = "SELECT * FROM RegisteredUser WHERE username = ? AND password = ? AND role = ?";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, username);
            stmt.setString(2, password);
            stmt.setString(3, role);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Show> getAvailableShows(Date date) {
        List<Show> shows = new ArrayList<>();
        String sql = "SELECT s.show_id, m.title, s.show_date, s.show_time, s.room_no, s.price, s.available_seats " +
                     "FROM `Show` s JOIN Movie m ON s.movie_id = m.movie_id WHERE s.show_date = ?";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setDate(1, date);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                shows.add(new Show(
                    rs.getInt("show_id"),
                    rs.getString("title"),
                    rs.getDate("show_date"),
                    rs.getTime("show_time"),
                    rs.getInt("room_no"),
                    rs.getDouble("price"),
                    rs.getInt("available_seats")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return shows;
    }

    public boolean makeReservation(String username, int showId, int ticketCount, String creditCard, double amount) {
        if (creditCard == null || !creditCard.matches("\\d{5}")) return false;
        Connection conn = null;
        try {
            conn = DatabaseConnector.getConnection();
            conn.setAutoCommit(false);

            PreparedStatement getUserStmt = conn.prepareStatement("SELECT user_id FROM RegisteredUser WHERE username = ?");
            getUserStmt.setString(1, username);
            ResultSet userRs = getUserStmt.executeQuery();
            if (!userRs.next()) return false;
            int userId = userRs.getInt("user_id");

            PreparedStatement showStmt = conn.prepareStatement("SELECT available_seats, show_date, show_time FROM `Show` WHERE show_id = ?");
            showStmt.setInt(1, showId);
            ResultSet showRs = showStmt.executeQuery();
            if (!showRs.next()) return false;
            int availableSeats = showRs.getInt("available_seats");
            Date showDate = showRs.getDate("show_date");
            Time showTime = showRs.getTime("show_time");
            if (ticketCount > availableSeats || ticketCount <= 0) return false;

            // Combine show date and time for comparison
            Timestamp showTimestamp = Timestamp.valueOf(showDate + " " + showTime);
            Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());

            // Check if show time is in the past
            if (showTimestamp.before(currentTimestamp)) {
                throw new IllegalArgumentException("❌ Cannot reserve tickets for past showtimes.");
            }

            String conflictSql = "SELECT COUNT(*) FROM Reservation r JOIN `Show` s ON r.show_id = s.show_id " +
                                 "WHERE r.user_id = ? AND s.show_date = ? AND s.show_time = ?";
            PreparedStatement conflictStmt = conn.prepareStatement(conflictSql);
            conflictStmt.setInt(1, userId);
            conflictStmt.setDate(2, showDate);
            conflictStmt.setTime(3, showTime);
            ResultSet conflictRs = conflictStmt.executeQuery();
            if (conflictRs.next() && conflictRs.getInt(1) > 0) return false;

            PreparedStatement insert = conn.prepareStatement(
                "INSERT INTO Reservation (user_id, show_id, ticket_count, credit_card, payment_amount, status) VALUES (?, ?, ?, ?, ?, 'Placed')");
            insert.setInt(1, userId);
            insert.setInt(2, showId);
            insert.setInt(3, ticketCount);
            insert.setString(4, creditCard);
            insert.setDouble(5, amount);
            insert.executeUpdate();

            PreparedStatement update = conn.prepareStatement("UPDATE `Show` SET available_seats = available_seats - ? WHERE show_id = ?");
            update.setInt(1, ticketCount);
            update.setInt(2, showId);
            update.executeUpdate();

            conn.commit();
            return true;

        } catch (IllegalArgumentException e) {
            try { if (conn != null) conn.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
            return false; // Propagate the "false" return
        }
         catch (Exception e) {
            e.printStackTrace();
            try { if (conn != null) conn.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
            return false;
        } finally {
            try { if (conn != null) conn.close(); } catch (SQLException e) { e.printStackTrace(); }
        }
    }

    public String getUserReservations(String username) {
        StringBuilder result = new StringBuilder();
        String sql = "SELECT r.reservation_id, m.title, s.show_date, s.show_time, r.ticket_count, r.payment_amount, r.status " +
                     "FROM Reservation r JOIN RegisteredUser u ON r.user_id = u.user_id " +
                     "JOIN `Show` s ON r.show_id = s.show_id JOIN Movie m ON s.movie_id = m.movie_id WHERE u.username = ?";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                result.append("Reservation ID: ").append(rs.getInt("reservation_id"))
                      .append(", Movie: ").append(rs.getString("title"))
                      .append(", Date: ").append(rs.getDate("show_date"))
                      .append(", Time: ").append(rs.getTime("show_time"))
                      .append(", Tickets: ").append(rs.getInt("ticket_count"))
                      .append(", Amount: $").append(rs.getDouble("payment_amount"))
                      .append(", Status: ").append(rs.getString("status"))
                      .append("\n");
            }
            return result.length() == 0 ? "❌ No reservations found." : result.toString();
        } catch (SQLException e) {
            e.printStackTrace();
            return "❌ Error retrieving reservations.";
        }
    }

    public boolean cancelReservation(int reservationId) {
        String sql = "SELECT s.show_time, s.show_date, r.ticket_count, r.show_id FROM Reservation r JOIN `Show` s ON r.show_id = s.show_id WHERE r.reservation_id = ?";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, reservationId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Date showDate = rs.getDate("show_date");
                Time showTime = rs.getTime("show_time");
                int ticketCount = rs.getInt("ticket_count");
                int showId = rs.getInt("show_id");
                Timestamp showTimestamp = Timestamp.valueOf(showDate + " " + showTime);
                Timestamp now = new Timestamp(System.currentTimeMillis());
                if (showTimestamp.getTime() - now.getTime() < 60 * 60 * 1000) return false;

                conn.setAutoCommit(false);
                PreparedStatement deleteRes = conn.prepareStatement("DELETE FROM Reservation WHERE reservation_id = ?");
                PreparedStatement updateSeats = conn.prepareStatement("UPDATE `Show` SET available_seats = available_seats + ? WHERE show_id = ?");
                deleteRes.setInt(1, reservationId);
                updateSeats.setInt(1, ticketCount);
                updateSeats.setInt(2, showId);
                deleteRes.executeUpdate();
                updateSeats.executeUpdate();
                conn.commit();
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean addMovie(String title, int rank, String review) {
        String sql = "INSERT INTO Movie (title, movie_rank, review) VALUES (?, ?, ?)";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, title);
            stmt.setInt(2, rank);
            stmt.setString(3, review);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean addShow(int movieId, String date, String time, int roomNo, double price) {
        try (Connection conn = DatabaseConnector.getConnection()) {
            // Calculate the end time of the new show (time + 3 hours)
            Time startTime = Time.valueOf(time);
            long startTimeMillis = startTime.getTime();
            long endTimeMillis = startTimeMillis + (3 * 60 * 60 * 1000); // Add 3 hours in milliseconds
            Time endTime = new Time(endTimeMillis);

            // Modified check for time conflicts within the 3-hour window
            String checkSql = "SELECT COUNT(*) FROM `Show` WHERE room_no = ? AND show_date = ? AND " +
                              "(show_time < ? AND ADDTIME(show_time, '03:00:00') > ?) "; //check for conflict
            try (PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
                checkStmt.setInt(1, roomNo);
                checkStmt.setDate(2, Date.valueOf(date));
                checkStmt.setTime(3, endTime);
                checkStmt.setTime(4, startTime);
                ResultSet rs = checkStmt.executeQuery();
                if (rs.next() && rs.getInt(1) > 0) {
                    return false; // Conflict found, don't add the show
                }
            }

            String sql = "INSERT INTO `Show` (movie_id, show_date, show_time, room_no, price, available_seats) VALUES (?, ?, ?, ?, ?, 40)";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, movieId);
                stmt.setDate(2, Date.valueOf(date));
                stmt.setTime(3, Time.valueOf(time));
                stmt.setInt(4, roomNo);
                stmt.setDouble(5, price);
                return stmt.executeUpdate() > 0;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public String getAllShowsInfo() {
        String sql = "SELECT s.show_id, m.title, s.show_date, s.show_time, s.room_no, s.price, s.available_seats FROM `Show` s JOIN Movie m ON s.movie_id = m.movie_id";
        StringBuilder result = new StringBuilder();
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                result.append("Show ID: ").append(rs.getInt("show_id"))
                      .append(", Movie: ").append(rs.getString("title"))
                      .append(", Date: ").append(rs.getDate("show_date"))
                      .append(", Time: ").append(rs.getTime("show_time"))
                      .append(", Room: ").append(rs.getInt("room_no"))
                      .append(", Price: $").append(rs.getDouble("price"))
                      .append(", Seats Left: ").append(rs.getInt("available_seats"))
                      .append("\n");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return "❌ Failed to load shows.";
        }
        return result.toString();
    }

    public boolean deleteShow(int showId) {
        String sql = "DELETE FROM `Show` WHERE show_id = ?";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, showId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public int getMovieIdByTitle(String title) {
        String sql = "SELECT movie_id FROM Movie WHERE title = ?";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, title);
            ResultSet rs = stmt.executeQuery();
            return rs.next() ? rs.getInt("movie_id") : -1;
        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
    }

    public List<String[]> getAllReservationsForChef() {
        String sql = "SELECT r.reservation_id, u.username, m.title, s.show_date, s.show_time, r.ticket_count, r.status " +
                     "FROM Reservation r JOIN RegisteredUser u ON r.user_id = u.user_id " +
                     "JOIN `Show` s ON r.show_id = s.show_id JOIN Movie m ON s.movie_id = m.movie_id";
        List<String[]> data = new ArrayList<>();
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                data.add(new String[]{
                    String.valueOf(rs.getInt("reservation_id")),
                    rs.getString("username"),
                    rs.getString("title"),
                    rs.getDate("show_date").toString(),
                    rs.getTime("show_time").toString(),
                    String.valueOf(rs.getInt("ticket_count")),
                    rs.getString("status")
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return data;
    }

    public boolean updateReservationStatus(int reservationId, String newStatus) {
        String sql = "UPDATE Reservation SET status = ? WHERE reservation_id = ?";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, newStatus);
            stmt.setInt(2, reservationId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // ✅ New method: Update Show Details
    public boolean updateShowDetails(int showId, String newTitle, int newRank, String newReview,
                                     String newDate, String newTime, int newRoom, double newPrice) {
        String getMovieSql = "SELECT movie_id FROM `Show` WHERE show_id = ?";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement getMovieStmt = conn.prepareStatement(getMovieSql)) {

            getMovieStmt.setInt(1, showId);
            ResultSet rs = getMovieStmt.executeQuery();

            if (!rs.next()) return false;
            int movieId = rs.getInt("movie_id");

            conn.setAutoCommit(false);

            // Update Movie
            PreparedStatement updateMovie = conn.prepareStatement("UPDATE Movie SET title = ?, movie_rank = ?, review = ? WHERE movie_id = ?");
            updateMovie.setString(1, newTitle);
            updateMovie.setInt(2, newRank);
            updateMovie.setString(3, newReview);
            updateMovie.setInt(4, movieId);
            updateMovie.executeUpdate();

            // Update Show
            PreparedStatement updateShow = conn.prepareStatement("UPDATE `Show` SET show_date = ?, show_time = ?, room_no = ?, price = ? WHERE show_id = ?");
            updateShow.setDate(1, Date.valueOf(newDate));
            updateShow.setTime(2, Time.valueOf(newTime));
            updateShow.setInt(3, newRoom);
            updateShow.setDouble(4, newPrice);
            updateShow.setInt(5, showId);
            updateShow.executeUpdate();

            conn.commit();
            return true;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}